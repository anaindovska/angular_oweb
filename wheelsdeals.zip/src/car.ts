export interface car{
    id: number,
    name: string,
    desc: string,
    specs: string,
    price: string,
    url: string,
    img: string,
}