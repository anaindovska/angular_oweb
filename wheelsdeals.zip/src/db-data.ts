

export const CARS: any = [

    {
        id: 1,
        name: "Porsche 911",
        desc: "2dr PDK [4 Seat] 3.0",
        specs: "10 miles Automatic Petrol",
        price: "£130,777",
        url: "https://www.autotrader.co.uk/car-search?advertising-location=at_cars&expired-ad=true&fromsra&make=Porsche&model=911&postcode=NW9%207RH&sort=relevance&year-from=new&year-to=new&refresh=true",
        img: "https://m.atcdn.co.uk/a/media/w1024/7dc41e63f72e4f56b84bb16789fc34cc.jpg",
        
    },
    {
        id: 2,
        name: "Audi S4",
        desc: "3.0 TDI V6 Black Edition Tiptronic quattro Euro 6 (s/s) 4dr",
        specs: "25 miles Automatic Diesel",
        price: "£54,980",
        url: "https://www.autotrader.co.uk/car-search?advertising-location=at_cars&expired-ad=true&fromsra&make=Audi&model=S4&postcode=NW9%207RH&sort=relevance&year-from=new&year-to=new",
        img: "https://m.atcdn.co.uk/a/media/w1024/6122d6bd5c684248b9fd33bcfd0aea54.jpg",
     
    },
    {
        id: 3,
        name: "Lexus RX",
        desc: "2.5 350h Prem Plus E-CVT 4WD Euro 6 (s/s) 5dr",
        specs: "10 miles Automatic Petrol Hybrid",
        price: "£69,220",
        url: "https://www.autotrader.co.uk/car-search?advertising-location=at_cars&expired-ad=true&fromsra&make=Lexus&model=RX&postcode=NW9%207RH&sort=relevance&year-from=new&year-to=new",
        img: "https://m.atcdn.co.uk/a/media/w1024/61981b37e18e41679502e520834fcd17.jpg",
       
    },
    
    

];
