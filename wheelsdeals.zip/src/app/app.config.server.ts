import { mergeApplicationConfig, ApplicationConfig } from '@angular/core';
import { provideServerRendering } from '@angular/platform-server';
<<<<<<< HEAD
import { appConfig } from './app.config';
=======
import { provideServerRouting } from '@angular/ssr';
import { appConfig } from './app.config';
import { serverRoutes } from './app.routes.server';
>>>>>>> ade7d94 (initial commit)

const serverConfig: ApplicationConfig = {
  providers: [
    provideServerRendering(),
<<<<<<< HEAD
=======
    provideServerRouting(serverRoutes)
>>>>>>> ade7d94 (initial commit)
  ]
};

export const config = mergeApplicationConfig(appConfig, serverConfig);
