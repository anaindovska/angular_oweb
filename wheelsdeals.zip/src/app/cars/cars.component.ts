import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { car } from '../../car';

@Component({
  selector: 'app-cars',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './cars.component.html',
  styleUrl: './cars.component.css'
})
export class CarsComponent {


  @Input() kola!: car;
  
}
