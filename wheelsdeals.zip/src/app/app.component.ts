import { Component, OnInit} from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CARS } from '../db-data';
import { CarsComponent } from './cars/cars.component';
import { car } from '../car';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone:true,
  imports: [RouterOutlet, CarsComponent, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
<<<<<<< HEAD
export class AppComponent {
<<<<<<< HEAD
  title = 'wheels_deals';
=======
  title = 'wheelsdeals';
>>>>>>> ade7d94 (initial commit)
=======
export class AppComponent implements OnInit{
  title = 'wheelsdeals';
  cars: car[]=[];

  ngOnInit(): void {
    this.cars=CARS;
    }
  




>>>>>>> 3189269 (proekt)
}
